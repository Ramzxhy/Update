module.exports = {
  BOT_TOKEN: "8251125458:AAH93lm2bLMmEZ0wCvknOZPSPctogmhFe3k",
  OWNER_ID: ["8161803979"],
};